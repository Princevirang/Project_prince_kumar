import torch
import torch.nn as nn
import torch.optim as optim
import os

from dataset import IsingDataset, isingLoader
from model import IsingCNN
from config import batch_size, epochs, learning_rate


def train_model(model, num_epochs, train_loader, loss_fn, optimizer):
    model.train()

    for epoch in range(num_epochs):
        total_loss = 0

        for batch_x, batch_y in train_loader:
            optimizer.zero_grad()

            outputs = model(batch_x)
            loss = loss_fn(outputs, batch_y) 

            loss.backward()
            optimizer.step()

            total_loss += loss.item()

        print(f"Epoch {epoch+1}/{num_epochs}, Loss: {total_loss:.4f}")

    
    os.makedirs("_checkpoints", exist_ok=True)
    torch.save(model.state_dict(), "_checkpoints/_final_weights.pth")

    

    return model


if __name__ == "__main__":
    print("Loading FULL dataset for training...")
    
    
    dataset = IsingDataset("full_data")  
    train_loader = isingLoader(dataset, batch_size)

    print(f"Dataset size: {len(dataset)} samples")

    model = IsingCNN()
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=learning_rate)

    train_model(model, epochs, train_loader, criterion, optimizer)