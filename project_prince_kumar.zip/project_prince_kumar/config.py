batch_size = 32
epochs = 30
learning_rate = 0.001

img_size = 50
data_path = "data"