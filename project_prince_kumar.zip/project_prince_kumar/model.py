import torch.nn as nn
import torch.nn.functional as F

class IsingCNN(nn.Module):
    def __init__(self):
        super(IsingCNN, self).__init__()

        self.conv1 = nn.Conv2d(1, 8, 3, padding=1)
        self.conv2 = nn.Conv2d(8, 16, 3, padding=1)

        self.pool = nn.MaxPool2d(2, 2)

        self.fc1 = nn.Linear(16 * 12 * 12, 32)
        self.fc2 = nn.Linear(32, 2)

    def forward(self, x):
        x = self.pool(F.relu(self.conv1(x)))  # 50 → 25
        x = self.pool(F.relu(self.conv2(x)))  # 25 → 12

        x = x.view(-1, 16 * 12 * 12)

        x = F.relu(self.fc1(x))
        x = self.fc2(x)

        return x