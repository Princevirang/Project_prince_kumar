# evaluate.py

import os
import torch
import numpy as np
from PIL import Image

from model import IsingCNN
from dataset import IsingDataset, isingLoader
from config import batch_size


L = 50
n_steps = 500
n_test_samples_per_class = 50  


ordered_T_range = (2.269, 2.269)    # Exactly at the critical point
disordered_T_range = (2.269, 2.269) # Exactly at the critical point

def init_lattice():
    return np.random.choice([-1, 1], size=(L, L))

def metropolis(lattice, T):
    for _ in range(L * L):
        i = np.random.randint(0, L)
        j = np.random.randint(0, L)
        s = lattice[i, j]
        neighbors = (
            lattice[(i+1)%L, j] + lattice[(i-1)%L, j] +
            lattice[i, (j+1)%L] + lattice[i, (j-1)%L]
        )
        dE = 2 * s * neighbors
        if dE < 0 or np.random.rand() < np.exp(-dE / T):
            lattice[i, j] *= -1

def generate_test_data():
  
    os.makedirs("test_data", exist_ok=True)
    
    test_labels = []
    counter = 0

   
    for i in range(n_test_samples_per_class):
        if i % 10 == 0:
            print(f"   [Progress] {i}/50 ordered images generated...", flush=True)
            
        lattice = init_lattice()
        T = np.random.uniform(*ordered_T_range)
        for _ in range(n_steps):
            metropolis(lattice, T)
            
        img = ((lattice + 1) / 2 * 255).astype(np.uint8)
        Image.fromarray(img).save(f"test_data/sample_{counter}.jpg")
        test_labels.append(1)
        counter += 1

    
    for i in range(n_test_samples_per_class):
        if i % 10 == 0:
            print(f"   [Progress] {i}/50 disordered images generated...", flush=True)

        lattice = init_lattice()
        T = np.random.uniform(*disordered_T_range)
        for _ in range(n_steps):
            metropolis(lattice, T)
            
        img = ((lattice + 1) / 2 * 255).astype(np.uint8)
        Image.fromarray(img).save(f"test_data/sample_{counter}.jpg")
        test_labels.append(0)
        counter += 1

    np.save("test_data/labels.npy", np.array(test_labels))
    

def test_accuracy():
   
    
   
    test_dataset = IsingDataset("test_data")
    test_loader = isingLoader(test_dataset, batch_size)

   
    model = IsingCNN()
    model.load_state_dict(torch.load("_checkpoints/_final_weights.pth"))
    model.eval()  

    correct = 0
    total = 0

    
    with torch.no_grad():
        for batch_x, batch_y in test_loader:
            outputs = model(batch_x)
            _, predicted = torch.max(outputs, 1)
            
            total += batch_y.size(0)
            correct += (predicted == batch_y).sum().item()

    accuracy = 100 * correct / total
  
    print(f"Model Accuracy: {accuracy:.2f}%")
  

if __name__ == "__main__":
    generate_test_data()
    test_accuracy()