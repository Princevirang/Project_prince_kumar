import torch
import numpy as np
from PIL import Image
from model import IsingCNN


from config import img_size


def predict_sample(file_paths):
    model = IsingCNN()
    
    
    model.load_state_dict(torch.load("_checkpoints/_final_weights.pth"))
    model.eval()

    batch = []

    for path in file_paths:
        img = Image.open(path).convert("L")
        
        
        img = img.resize((img_size, img_size))
        
        x = np.array(img, dtype=np.float32) / 255.0
        x = x - np.mean(x)

        x = torch.tensor(x).unsqueeze(0)
        batch.append(x)

   
    batch = torch.stack(batch)

    with torch.no_grad():
        outputs = model(batch)
        _, preds = torch.max(outputs, 1)

   
    labels = ["Ordered" if p == 1 else "Disordered" for p in preds.tolist()]

    return labels



if __name__ == "__main__":
    import os

   
    data_dir = "data"
    
    if os.path.exists(data_dir):
        files = [os.path.join(data_dir, f) for f in os.listdir(data_dir) if f.endswith(".jpg")]
        
       
        files = sorted(files)

        if files:
            
            preds = predict_sample(files)
            
            print("\n" + "="*50)
            print(f"{'IMAGE FILENAME':<25} | {'MODEL PREDICTION':<15}")
            print("-" * 50)
            
            for file_path, prediction in zip(files, preds):
                filename = os.path.basename(file_path)
                print(f"{filename:<25} | {prediction:<15}")
                
            print("="*50 + "\n")
