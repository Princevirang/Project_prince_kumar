from model import IsingCNN as TheModel
from dataset import IsingDataset as TheDataset
from dataset import isingLoader as the_dataloader
from train import train_model as the_trainer
from predict import predict_sample as the_predictor

# Added the required configuration imports
from config import batch_size as the_batch_size
from config import epochs as total_epochs