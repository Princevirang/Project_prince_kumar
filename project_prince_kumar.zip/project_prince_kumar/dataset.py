import os
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from PIL import Image


from config import img_size 

class IsingDataset(Dataset):
    def __init__(self, data_path):
        self.data_path = data_path

        
        self.image_files = sorted(
            [f for f in os.listdir(data_path) if f.endswith(".jpg")],
            key=lambda x: int(x.split('_')[1].split('.')[0])
        )

        self.labels = np.load(os.path.join(data_path, "labels.npy"))

    def __len__(self):
        return len(self.image_files)

    def __getitem__(self, idx):
        img_path = os.path.join(self.data_path, self.image_files[idx])

      
        img = Image.open(img_path).convert("L")
        
        
        img = img.resize((img_size, img_size))

        x = np.array(img, dtype=np.float32) / 255.0

     
        x = x - np.mean(x)

        x = torch.tensor(x).unsqueeze(0)  
        y = torch.tensor(self.labels[idx], dtype=torch.long)

        return x, y


def isingLoader(dataset, batch_size):
    return DataLoader(dataset, batch_size=batch_size, shuffle=True)