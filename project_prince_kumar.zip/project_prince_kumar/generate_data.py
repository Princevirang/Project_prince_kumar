import numpy as np
import os
from PIL import Image


L = 50
n_steps = 500
n_samples_per_class = 200   # training data

ordered_T_range = (2.0, 2.2)
disordered_T_range = (2.3, 2.5)


def init_lattice():
    return np.random.choice([-1, 1], size=(L, L))


def metropolis(lattice, T):
    for _ in range(L * L):
        i = np.random.randint(0, L)
        j = np.random.randint(0, L)

        s = lattice[i, j]
        neighbors = (
            lattice[(i+1)%L, j] +
            lattice[(i-1)%L, j] +
            lattice[i, (j+1)%L] +
            lattice[i, (j-1)%L]
        )

        dE = 2 * s * neighbors

        if dE < 0 or np.random.rand() < np.exp(-dE / T):
            lattice[i, j] *= -1



os.makedirs("full_data", exist_ok=True)
os.makedirs("data", exist_ok=True)

full_labels = []
submission_labels = []

counter = 0

print("Generating ordered")
for i in range(n_samples_per_class):
    lattice = init_lattice()
    T = np.random.uniform(*ordered_T_range)

    for _ in range(n_steps):
        metropolis(lattice, T)

    # Save FULL dataset
    img = ((lattice + 1) / 2 * 255).astype(np.uint8)
    Image.fromarray(img).save(f"full_data/sample_{counter}.jpg")
    full_labels.append(1)

  

print("Generating disordered...")
for i in range(n_samples_per_class):
    lattice = init_lattice()
    T = np.random.uniform(*disordered_T_range)

    for _ in range(n_steps):
        metropolis(lattice, T)

    img = ((lattice + 1) / 2 * 255).astype(np.uint8)
    Image.fromarray(img).save(f"full_data/sample_{counter}.jpg")
    full_labels.append(0)

    if i < 10:
        Image.fromarray(img).save(f"data/sample_{len(submission_labels)}.jpg")
        submission_labels.append(0)

    counter += 1


# Save labels
np.save("full_data/labels.npy", np.array(full_labels))
np.save("data/labels.npy", np.array(submission_labels))
